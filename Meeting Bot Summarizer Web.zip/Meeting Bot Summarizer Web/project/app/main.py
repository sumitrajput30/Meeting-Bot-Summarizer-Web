from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.database import engine, SessionLocal, Base
from app.models import Meeting
from app.ai_service import generate_summary

app = FastAPI()

# Create database tables automatically
Base.metadata.create_all(bind=engine)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/meeting/create", response_class=HTMLResponse)
def create_meeting(
    request: Request,
    title: str = Form(...),
    meeting_type: str = Form(...),
    transcript: str = Form(...)
):
    # Generate AI output
    ai_data = generate_summary(transcript)

    # Save meeting to SQLite
    db = SessionLocal()
    meeting = Meeting(
        title=title,
        meeting_type=meeting_type,
        transcript=transcript,
        summary=ai_data["summary"]
    )
    db.add(meeting)
    db.commit()
    db.close()

    return templates.TemplateResponse(
        "result.html",
        {
            "request": request,
            "title": title,
            "meeting_type": meeting_type,
            "summary": ai_data["summary"],
            "points": ai_data["key_points"],
            "actions": ai_data["action_items"]
        }
    )
