from django.shortcuts import render, redirect
from .models import Meeting
from .ai_service import generate_summary

def create_meeting(request):
    if request.method == "POST":
        title = request.POST['title']
        meeting_type = request.POST['meeting_type']
        transcript = request.POST.get('transcript', '')

        ai_output = generate_summary(transcript)

        meeting = Meeting.objects.create(
            title=title,
            meeting_type=meeting_type,
            transcript=transcript,
            ai_output=ai_output
        )

        return render(request, 'result.html', ai_output)

    return render(request, 'create.html')

def meeting_history(request):
    meetings = Meeting.objects.all().order_by('-created_at')
    return render(request, 'history.html', {'meetings': meetings})

def delete_meeting(request, id):
    Meeting.objects.get(id=id).delete()
    return redirect('history')
