from django.db import models

class Meeting(models.Model):
    MEETING_TYPES = [
        ('Team', 'Team'),
        ('Interview', 'Interview'),
        ('Client', 'Client'),
        ('Standup', 'Standup'),
    ]

    title = models.CharField(max_length=200)
    meeting_type = models.CharField(max_length=20, choices=MEETING_TYPES)
    transcript = models.TextField(blank=True)
    ai_output = models.JSONField()
    audio_file = models.FileField(upload_to='meetings/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
