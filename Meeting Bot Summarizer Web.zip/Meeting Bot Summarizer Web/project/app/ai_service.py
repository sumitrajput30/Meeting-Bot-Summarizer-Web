import openai
import json

openai.api_key = "YOUR_API_KEY"

def generate_summary(transcript):
    prompt = f"""
Return JSON:
summary,
key_points,
decisions,
action_items (task, owner, due_date),
agenda

Transcript:
{transcript}
"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role":"user","content":prompt}],
        temperature=0.3
    )

    return json.loads(response.choices[0].message.content)
